# UI Wireframes

Owner Dashboard, Admin Dashboard, Technician Dashboard, Customers, Cars, Jobs, POS, Inventory, Reports.
