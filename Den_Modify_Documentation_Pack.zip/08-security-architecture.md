# Security Architecture

RBAC, RLS, Audit Logs, Backups.
