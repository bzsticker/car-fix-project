# API Specification

Auth, Customers, Cars, Jobs, Quotations, Invoices, POS, Inventory, Reports.
