# SQL Migrations

Production migration strategy.

## Core Tables
- branches
- users
- customers
- cars
- jobs
...

## Rules
- UUID primary keys
- Soft delete
- Index strategy
- Foreign keys
- RLS enabled
