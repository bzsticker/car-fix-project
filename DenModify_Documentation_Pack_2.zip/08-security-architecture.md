# Security Architecture

## RBAC
Owner, Admin, Technician

## RLS
Branch isolation.

## Audit Logs
Track create/update/delete/login.

## Security
JWT, HTTPS, session policies.
